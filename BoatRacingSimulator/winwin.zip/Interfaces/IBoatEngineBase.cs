﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IBoatEngineBase : IModelable
    {
        int Output { get; }
    }
}