﻿namespace BoatRacingSimulator.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}